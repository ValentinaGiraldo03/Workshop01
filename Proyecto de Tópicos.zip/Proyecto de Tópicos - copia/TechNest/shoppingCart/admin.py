from django.contrib import admin
from .models import shoppingCart,CartProduct


# Register your models here.
admin.site.register(shoppingCart)
admin.site.register(CartProduct)