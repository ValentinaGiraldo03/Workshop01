from django.urls import path, include
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('user/', include('user.urls')),

    path('register/', views.register, name='register'),

    path('register_administrator/', views.register_administrator, name='register_administrator'),

    path('register_client/', views.register_client, name='register_client'),

    path('login/', views.login, name='login'),

    #path('logout/', auth_views.LogoutView.as_view(template_name='user/logout.html'), name='logout'),
]
