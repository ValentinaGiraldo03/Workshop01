from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from .models import User
from django.forms.widgets import TextInput, PasswordInput
from .models import Administrator,Client

'''class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'user_type')


class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=TextInput())
    password = forms.CharField(widget=PasswordInput())'''

class UserTypeForm(forms.Form):
    USER_CHOICES = [
        ('administrator', 'Administrator'),
        ('client', 'Client'),
    ]
    user_type = forms.ChoiceField(
        label='User Type',
        choices=USER_CHOICES,
        widget=forms.RadioSelect(attrs={
            'class': 'w-4 h-4 border-gray-300 focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-600 dark:focus:bg-blue-600 dark:bg-gray-700 dark:border-gray-600'
        })
    )

class AdministratorRegistrationForm(forms.Form):
    username = forms.CharField(label='Username')
    email = forms.EmailField(label='Email')
    password = forms.CharField(label='Password', widget=forms.PasswordInput)
    

class ClientRegistrationForm(forms.Form):
    username = forms.CharField(label='Username')
    email = forms.EmailField(label='Email')
    password = forms.CharField(label='Password', widget=forms.PasswordInput)


class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=TextInput())
    password = forms.CharField(widget=PasswordInput())